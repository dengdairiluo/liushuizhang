# Adguard
原理，通过一个vpn来拦截各种广告。只要路过vpn基本可以为所欲为了