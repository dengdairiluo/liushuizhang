# Thinkpad p73

哇哇哇，爽啊