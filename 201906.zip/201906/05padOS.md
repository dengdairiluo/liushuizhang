# pad OS 
同事的ipad已经变砖了