# 1SecondEveryday

概念很好，每天一秒钟的vlog记录自己一天。回忆起来应该不错，不过用户可能会太懒。