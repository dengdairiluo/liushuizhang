# Windows Terminal

垃圾软件，需要自行编译。有bug，反正我不是win系统，无意义