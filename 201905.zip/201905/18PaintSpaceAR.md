# Paint Space AR

为什么感觉就是拍照，然后在上面涂鸦？没太看出来AR的特色。
